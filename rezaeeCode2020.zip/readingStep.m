
%--------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------
% A matlab code to detect the Multiple Sclerosis in MR images using supervised 
% evolutionary extreme learning machine based on multiple feature descriptors 
% Step 1 ----->>> Fractal and Pseudo Zernike Moments feature extraction
% Author: Khosro Rezaee
% Last modified: 11/03/2019
% email: Kh.rezaee.biomedeng@gmail.com
%--------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------


clc; clear; close all

disp ('This program takes a few minutes to run')
disp ('Step 1 ----->>> Fractal and Pseudo Zernike Moments feature extraction')
disp ('Please be patient.....................................')

%% -------------------------------------necessary pathes--------------------------------------
CurrentPath = pwd;
addpath (genpath(CurrentPath))

%% ---------------------------------------intializing-----------------------------------------
N = 2;
M = 10;
featuresVector = [];
Counter = 1;

%% ------------------------------------reading MRI images---------------------------------------
tic
cur_add=pwd;
adres_in=[cur_add '\ROI\'];
dir_adres_in=dir([adres_in '*.jpg']);

info_adres='info.txt';
fid=fopen(info_adres,'r');
info=textscan(fid,'%s %s %s %s %d %d %d');
fclose(fid);

%% ---------------------------------feature extraction step--------------------------------------
disp('...............Feature extraction step......................')
disp('............................................................')
for i=1:length(info{1,1})
    fprintf('\tThe feature vector of processed image: %d\n', i);
    if strcmp(info{1,3}{i},'NORM') 
        Image =(imread([adres_in,info{1,1}{i},'.jpg']));
        pause (0.1); imagesc(Image); axis off
        fractalFeatures = sfta(Image,8);
        pseudoZernikeMoments = momentsFeaturesExtraction(Image,N,M)';
        atrributes = [pseudoZernikeMoments,fractalFeatures];
        featuresVector=[featuresVector; atrributes];
        label(Counter) = 1;  % creating labels
        Counter = Counter+1;
    elseif strcmp(info{1,3}{i},'ABNORMAL') 
        Image = imread([adres_in,info{1,1}{i},'.jpg']);
        pause(0.1); imagesc(Image); axis off
        fractalFeatures = sfta(Image,8);
        pseudoZernikeMoments = momentsFeaturesExtraction(Image,N,M)';
        atrributes = [pseudoZernikeMoments,fractalFeatures];
        featuresVector=[featuresVector; atrributes];
        label(Counter) = 2;  % creating labels
        Counter = Counter+1;
    end
end

%% ------------------------------------results saving---------------------------------------
save('msData','featuresVector','label')

toc
%% 







