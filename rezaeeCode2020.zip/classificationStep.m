
%--------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------
% A matlab code to detect the Multiple Sclerosis in MR images using supervised 
% evolutionary extreme learning machine based on multiple feature descriptors 
% Step 2 ----->>> DE feature selection and ELM-SFLA classification
% Author: Khosro Rezaee
% Last modified: 11/03/2019
% email: Kh.rezaee.biomedeng@gmail.com
%--------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------

clc; clear; close all

disp ('This program takes a few minutes to run')
disp ('Step 2 ----->>> DE feature selection and ELM-SFLA classification')
disp ('Please be patient.....................................')

%% -------------------------------------necessary pathes--------------------------------------
CurrentPath = pwd;
addpath (genpath(CurrentPath))

%% ---------------------------------------intializing-----------------------------------------
fsNumKfold = 5;
classificationNumKfold = 10;
numOfGoldFeat = 10; 
sflaMaxIteration = 30;

%% --------------------------------loading features and label--------------------------------
load msData
mindata = min(featuresVector);
maxdata = max(featuresVector);
Normalized = bsxfun(@rdivide,bsxfun(@minus,featuresVector,mindata),maxdata-mindata);
featuresVector = Normalized;

%% -------------------------------- DE - feature selection--------------------------------
disp('Feature selection level .......')
[~,EvolutionaryIndex] = DEFS(featuresVector,label,numOfGoldFeat,100,0,'FitSVM',1,fsNumKfold);
[uniqueValues,~,uniqueIndex] = unique(EvolutionaryIndex);
frequency = accumarray(uniqueIndex(:),1)./numel(EvolutionaryIndex);
[sorted, indices] = sort(frequency,'descend');
GoldFeaturesIndex = uniqueValues(indices)';
Selected_Features = featuresVector(:,GoldFeaturesIndex(1,1:numOfGoldFeat));
Ind = GoldFeaturesIndex(1,1:numOfGoldFeat);
dataReduction = featuresVector(:,Ind);
disp('Feature selection finished .......')
disp('....................................................................')


indices = crossvalind('kfold',label,classificationNumKfold);

for i = 1:classificationNumKfold 
    disp('---------------------------------------------------------------') 
    disp(['The number of K-fold loop is ------>>> ' num2str(i)])
    
    test = (indices==i); 
    train = ~test;
  
    train_Data = dataReduction(train,:);
    train_Label = label(train)';
    test_Data = dataReduction(test,:);
    test_Label = label(test)';
    
    trainData.Inputs = train_Data;
    trainData.Targets = train_Label;
    
    %% Network Structure
    
    %% Train Network Using SFLA 
    Out = TrainUsingSFLA(trainData,sflaMaxIteration); 
    
    %% Test Network 
    TestingAccuracy = AccCalculation(Out,test_Data, test_Label,sflaMaxIteration);
    
    [FinalAccuracy(i),BestNetAddress(i)] = max(cell2mat(TestingAccuracy)); 
    disp(['Accuracy of test classificaion is ===> ',num2str(FinalAccuracy(i))]) 
    BestNet{i} = Out{BestNetAddress(i)}.Network;
    
end

fprintf('================Final Average Results:================');
fprintf('Mean Test Accuracy: %.2f%%\n',100*mean(FinalAccuracy))


