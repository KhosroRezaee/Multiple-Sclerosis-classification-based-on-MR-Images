function nVar = NumberVariables(Network)
IW = Network.IW{1,1}; IW_Num = numel(IW);
LW = Network.LW{2,1}; LW_Num = numel(LW);
b1 = Network.b{1,1}; b1_Num = numel(b1);
b2 = Network.b{2,1}; b2_Num = numel(b2);
nVar = IW_Num + LW_Num + b1_Num + b2_Num; 

end