
function [Cost,Out] = Cost_SFLA_NN(W,Data)
    %Network = Data.Network;
    Inputs = Data.Inputs;
    Targets = Data.Targets;
    
    NumKfold = 5;
    Elm_Type = 1;
    NumberofHiddenNeurons=20;
    ActivationFunction='hardlim';
     
    indices = crossvalind('kfold',Targets,NumKfold);

    for i = 1 : NumKfold
            Validation = (indices==i); 
            trainTwo = ~Validation;
  
            Train_Data = Inputs(trainTwo,:);
            Train_Label = Targets(trainTwo);
            Validation_Data = Inputs(Validation,:);
            Validation_Label = Targets(Validation); 
            
            [Out{i},TrainingAccuracy(i)] = elm_train(Train_Data,Train_Label, Elm_Type, NumberofHiddenNeurons, ActivationFunction);
            [~, ValidationAcc(i)] = elm_predict(Out{i},Validation_Data,Validation_Label); 
    end
      
    [FinalAcc,Address] = max(ValidationAcc);  
    Out = Out{1,Address};
    
    
% % % % %     Network = ConsNet_Fcn(Network,W);
% % % % %     TNet = Network(Inputs');
% % % % %     TNet = TNet(:);
% % % % %     TNet(TNet>3) = 4;
% % % % %     TNet(TNet<=3) = 2;
% % % % %     C = mse(TNet - Targets);
%     e = TNet - Targets;
%     RMSE = (sum(e.^2)/numel(e))^0.5;
    Cost = 1-FinalAcc;    
    %Out.z = Cost;
    %Out.W = W;
    Out.Network = Out;
    %Out.TNet = TNet;
end