
function TestAcc = AccCalculation(Net,Test_Data, Test_Label,MaxIteration)


    for s = 1 :  MaxIteration  
        [q, TestAcc{s}] = elm_predict(Net{s},Test_Data,Test_Label); 
    end
end