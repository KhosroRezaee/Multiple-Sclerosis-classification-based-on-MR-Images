% Optimize Neural Network Weights Using...
% Shuffled Frog-Leaping Algorithm(SFLA-2006)
clc
clear
close all


%% Load Data
Data = LoadData();

%% Normalaization
Inputs = Data.Inputs;
% Inputs = Normalaization(Inputs);
Data.Inputs = Inputs;
Targets  = Data.Targets;
%% Test and Train Data

TrPercent = 70;
TrNum = round(Data.NSamples * TrPercent / 100);
TsNum = Data.NSamples - TrNum;

R = randperm(Data.NSamples);
trIndex = R(1 : TrNum);
tsIndex = R(1+TrNum : end);

TrainData.Inputs = Inputs(trIndex,:);
TrainData.Targets = Targets(trIndex,:);

TestData.Inputs = Inputs(tsIndex,:);
TestData.Targets = Targets(tsIndex,:);

%% Network Structure
TrainInputs = [TrainData.Inputs]';
Nneuron = [15 5];
FunctionActivation = {'tansig' 'tansig' 'purelin'};
Network = newff(TrainInputs,[TrainData.Targets]',Nneuron,FunctionActivation);
TrainData.Network = Network;

 Network = train(Network,TrainInputs,[TrainData.Targets]');
%% Train Network Using SFLA
[Network,Out] = TrainUsingSFLA(TrainData);

%% Test Network
Targets = TestData.Targets;
Outputs = Network([TestData.Inputs]');

Outputs = Outputs(:);
% ROC Curve
[X,Y] = perfcurve(Targets,Outputs,4);
figure,plot(X,Y)
xlabel('False positive rate')
ylabel('True positive rate')
title('ROC for Classification by Neural Networks')

% MSE Mesure
OutPuts = Outputs;
OutPuts(OutPuts<=3) = 0;
OutPuts(OutPuts>3) = 1;
Targets(Targets<=3) = 0;
Targets(Targets>3) = 1;

MSE = mse(OutPuts - Targets);
disp(['MSE = ',num2str(MSE)])

Accuracy = 100*(1 - MSE);
disp(['Accuracy = ',num2str(Accuracy)])

%% 
CM  = confusionmat(Targets,OutPuts);
S = 0;
for ii = 1:size(CM,1)
    S = S + CM(ii,ii);
end
Acc = S/numel(TestData.Targets);

figure,plotconfusion(Targets',OutPuts')





