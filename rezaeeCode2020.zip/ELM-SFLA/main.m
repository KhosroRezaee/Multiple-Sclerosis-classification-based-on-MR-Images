

indices = crossvalind('kfold',Targets,NumKfold);

for i = 1:NumKfold 
    
    disp(['The number of K-fold loop is ------>>>>>>>>>>>> ' num2str(i)])
    
    test = (indices==i); 
    train = ~test;
  
    Train_Data = ReducedData(train,:);
    Train_Label = Targets(train);
    Test_Data = ReducedData(test,:);
    Test_Label = Targets(test);
    
    TrainData.Inputs = Train_Data;
    TrainData.Targets = Train_Label;
    
    %% Network Structure
    
    %% Train Network Using SFLA 
    
    Out = TrainUsingSFLA(TrainData,MaxIteration); 
    
    %% Test Network 
    TestingAccuracy = AccCalculation(Out,Test_Data, Test_Label,MaxIteration_Classification);
    
    [BestTestAccuracy(i),BestNetAddress(i)] = max(cell2mat(TestingAccuracy)); 
    disp(['Accuracy of test classificaion is ===> ',num2str(BestTestAccuracy(i))]) 
    BestNet{i} = Out{BestNetAddress(i)}.Network;
end

toc
