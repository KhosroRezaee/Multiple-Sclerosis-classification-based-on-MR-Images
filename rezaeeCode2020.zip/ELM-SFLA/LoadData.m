function Data = LoadData()
%load('Data.mat')
load OriginalWBC

Inputs = fillmissing(Data,'constant', median(Data, 'omitnan'));
clear Data
Data.Targets = Label;
Data.Inputs = Inputs;
Data.NSamples = size(Inputs,1);
Data.NFeatures = size(Inputs,2);
Data.NOutputs = size(Label,2);
end




