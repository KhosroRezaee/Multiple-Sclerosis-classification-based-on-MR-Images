function [Results,Values] = Contingency_Table(gold,test_outcome)
 
% sens, spec, ppv and npv stand for sensitivity, specificity,
% positive predictive value, and negative predictive value

% True positives
TP = test_outcome(gold == 1);
TP = length(TP(TP == 1));

% False positives
FP = test_outcome(gold == 2);
FP = length(FP(FP == 1));

% False negatives
FN = test_outcome(gold == 1);
FN = length(FN(FN == 2));

% True negatives
TN = test_outcome(gold == 2);
TN = length(TN(TN == 2));

% Sensitivity
sens = TP/(TP+FN);

% Specificity
spec = TN/(FP+TN);

% Positive predictive value
ppv = TP/(TP+FP);

% Negative predictive value
npv = TN/(FN+TN);
Acc = (TP+TN)/(TP+TN+FN+FP);

Results.Acc = Acc;
Results.Spec = spec;
Results.Sens = sens;

Values.TP = TP;
Values.TN = TN;
Values.FN = FN;
Values.FP = FP;
end