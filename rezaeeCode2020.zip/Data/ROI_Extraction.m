
%--------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------
% In the name of God
% A matlab code to detect MS lesion in MR images
% "Intelligent MS lesion Detection on MR images"
% Author: Mrs. Shima Zargarani
% Last modified: 08/14/2016
%--------------------------------------------------------------------------------------------
%--------------------------------------------------------------------------------------------

% Step 1: Region of images (ROI) segmantation 
clear
close all
clc
warning off

%--------------------------------------------------------------------------------------------
cur_add = pwd;
addpath('Pre-Processes')
adres_in=[cur_add '\Data\'];
dir_adres_in=dir([adres_in '*.jpg']);
adres_out='ROI\';

%--------------------------------------------------------------------------------------------
% Reading Database Info
info_adres='info.txt';
fid=fopen(info_adres,'r');
info=textscan(fid,'%s %s %s %s %d %d %d');
fclose(fid);

%--------------------------------------------------------------------------------------------
disp('...............Region of images (ROI) segmantation step......................')

for i=1:size(dir_adres_in,1)
    
    fprintf('\tImage.No. %d\n', i);
        im=rgb2gray(imread([adres_in,info{1,1}{i},'.jpg']));
        pause (0.1)
        imshow (im)
        redundan_im = redundancy_process( im );
        imwrite(redundan_im,[adres_out,info{1,1}{i},'.jpg']);
end
close all
disp('ROI extraction finished')
