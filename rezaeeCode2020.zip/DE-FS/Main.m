

clc
clear
warning off

addpath('D:\Under Writing\Hepatitis\Code Mordade 95\Data')
addpath ('Opt')


global gamma
global ci
global x1
global x2

clear gamma ci x1 x2

NumOfGoldFeat = 6;       % Desired Number of Selected Features
MaxIt = 20;      % Maximum Number of Iterations in PSO Feature Selection
NumKfold = 10;

load UCI_Hepatits_Database

% imputedValues = knnimpute(UCI_Hepatits_Database)
% data=knnimpute(UCI_Hepatits_Database,1,'Distance', 'seuclidean');
data=UCI_Hepatits_Database;

label=data(:,1);
label(label==2)=0;
Label=(label+1); % 2 Dead  & 1 Alive
data(:,1)=[];

for i=1:size(data,2)
    temp=data(:,i);
    ind=~isnan(temp);
    ind1=ind & logical(label);
    ind0=ind & ~logical(label);
    m1=mean(temp(ind1));
    m0=mean(temp(ind0));
    temp(logical(label) & isnan(temp))=m1;
    temp(~logical(label) & isnan(temp))=m0;
    data(:,i)=temp;
end

Input=data;
mindata = min(Input);
maxdata = max(Input);
Data = bsxfun(@rdivide,bsxfun(@minus, Input, mindata),maxdata - mindata);

[~,EvolutionaryIndex] = DEFS(Data,Label,NumOfGoldFeat,1000,0,'FitSVM',10,NumKfold);

[uniqueValues,~,uniqueIndex] = unique(EvolutionaryIndex);
frequency = accumarray(uniqueIndex(:),1)./numel(EvolutionaryIndex);

[sorted, indices] = sort(frequency,'descend');
GoldFeaturesIndex = uniqueValues(indices)';

Selected_Features = Data(:,GoldFeaturesIndex(1,1:NumOfGoldFeat));

Ind =GoldFeaturesIndex(1,1:NumOfGoldFeat);

ReducedData = Data(:,Ind);
indices = crossvalind('kfold',Label,NumKfold);
for i = 1 : NumKfold
    
    test = (indices==i);
    train = ~test;
    
    % ------------------------------Data dividing---------------------------------
    TrainData = ReducedData(train,:);
    TrainLabel = Label(train);
    TestData = ReducedData(test,:);
    TestLabel = Label(test);
    
save('Info','TrainData','TrainLabel','TestData','TestLabel')

    nvars=2*size(Data,2);
    PopulationSize=20;
    MaxGenerations=200;
    FitnessLimit=0;

    c = Genetic_Algorithm (nvars,PopulationSize,MaxGenerations,FitnessLimit);
    
    gamma =abs (c(1));
    ci = abs(c(2));
    x1 = abs(c(3));
    x2 = abs(c(4));

    Model = fitcsvm(TrainData,TrainLabel,'KernelFunction', 'rbf',...
        'KernelScale', gamma, 'Standardize', true, 'BoxConstraint', ci,'Cost',[0,x1;x2,0]);
    
    Predicted_Train_Labels_New  = predict(Model,TrainData);
    NewSVMTrain = confusionmat(TrainLabel,Predicted_Train_Labels_New);
    Err_MultiNewSvm_Train(i)  = 1 - sum(diag(NewSVMTrain))/sum(NewSVMTrain(:));
    
    Predicted_Test_Labels_New =  predict(Model,TestData);
    NewSVMTest = confusionmat(TestLabel,Predicted_Test_Labels_New);
    Err_MultiNewSvm_Test(i)  = 1 - sum(diag(NewSVMTest))/sum(NewSVMTest(:));
      
    disp ('***************************************************************')
    disp(['The number of K-fold loop: ' num2str(i)])
    disp (['Err-SVM-Train = ' num2str(Err_MultiNewSvm_Train(i))])
    disp(['Err-SVM-Test = ' num2str(Err_MultiNewSvm_Test(i))])
    
end
Acc_Trian  = 1 - mean(Err_MultiNewSvm_Train)
Acc_Test  = 1 - mean(Err_MultiNewSvm_Test)
    


