function [Err,Subset] = DEFS(Data,Label,DNF,PSIZE,Ld,classif,GEN,NumKfold)
%%
warning off
Elm_Type = 1;
NumberofHiddenNeurons = 10;
Kernel_type = 'RBF_kernel';
Kernel_para = [0.1,10,100];
Regularization_coefficient = 1;

indices = crossvalind('kfold',Label,NumKfold);
for p = 1 : NumKfold
    
    test = (indices==p);
    train = ~test;
    
    % ------------------------------Data dividing---------------------------------
    data_tr = Data(train,:);
    label_tr = Label(train);
    data_ts = Data(test,:);
    label_ts = Label(test);

   disp(['The number of K-fold loop: ' num2str(p)])
%    Differential Evolution based Feature Selection
%    Inputs
%    ------
%          data_tr: training dataset (with NP1 patterns x NF+1 features with last column being the training class label)
%          data_ts: testing dataset (with NP1 patterns x NF+1 features with last column being the testing class label)
%          NP:   number of patterns (NP1 and NP2 used for example)
%          NF:   number of features
%          DNF:  desired number of features to be selected
%          PSIZE:population size
%          Ld:   either load initial population (Ld=1) or simply initialize a new population (Ld=0)
%          classif:  takes text value as: 'LDA' or 'KNN' or 'NB' or 'RegTree' 
%          GEN:     number of generations or iterations
%
%    OutPuts
%    -------
%          Err: Achieved error rate across the different itreations
%          Subset: selected feature subset (feature indices)
%
%    Example:
%    -------
%          load iris.dat
%          [Err,Subset] = DEFS(iris(1:2:end,1:end),iris(2:2:end,:),3,50,0,0,100)
%
%    References:
%    [1] R. N. Khushaba, A. Al-Ani, and A. Al-Jumaily, "Feature subset selection using differential evolution and a statistical repair mechanism",
%        Expert Systems with Applications, vol. 38, no. 9, pp. 11515-11526, 2011.
%
% DEFS by Dr. Rami Khushaba
% Research Fellow - Faculty of Engineering and IT
% University of Technology, Sydney.
% URL: www.rami-khushaba.com
%%
% CONTROL PARAMETERS %
D = DNF; % dimension of problem
NP = PSIZE; % size of population
CR = 0.5; % crossover constant
L = 1; % low boundary constraint
H = size(data_tr,2)-1; % high boundary constraint
NF = H;
NE = 5;
% Ld
if nargin < 5 || isempty(Ld),
    Ld = 0;
end
if nargin < 6 || isempty(classif),
    classif = 0;
end
if nargin < 7 || isempty(GEN),
    GEN = 400; % number of generations=iterations
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This section can be used to replace the factor F in the paper
w_start = 0.95;                          %Initial inertia weight's value
w_end = 0.35;                            %Final inertia weight
w_varyfor = 1;
w_varyfor = floor(w_varyfor*GEN);       %Weight change step. Defines total number of iterations for which weight is changed.
w_now = w_start;
inertdec = (.95-.35)/w_varyfor;           %Inertia weight's change per iteration
w_start = 0.35;                          %Initial inertia weight's value
w_end = 0.95;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% *************************** %
% ** ALGORITHM VARIABLES ** %
% *************************** %
X = zeros(D,1); % trial vector
Pop = zeros(D,NP); % population
Fit = zeros(1,NP); % fitness of the population
r = zeros(3,1); % randomly selected indices
% *********************** %
% ** CREATE POPULATION ** %
% *********************** %
% initialize random number generator
rand('state',sum(100*clock));
if Ld,
    load TabK Pop
    %Pop = Tab';
else
    for j=1:NP,
        FF = randperm(H);
        Pop(:,j) = FF(1:D)'; % within b.constraints
    end
end
for j = 1:NP % initialize each individual
    val =round(Pop(:,j))';
    switch classif
        case 'LDA'
            %LDA classifier
            Ac1 = classify(data_ts(:,val),data_tr(:,val),label_tr,'quadratic');
            Fit(1,j)=1-sum(Ac1~=label_ts)/size(data_ts,1);
        case 'KNN'
            %kNN classifier
            knn = fitcknn(data_tr(:,val),label_tr,'NumNeighbors',max(unique (Label)));
                predicted_label = knn.predict(data_ts(:,val));
                rknnTe = find(label_ts==predicted_label);
%                 Ac1 = knnclassify(data_ts(:,val),data_tr(:,val),label_tr,3);
%                 f=sum(Ac1~=label_ts)/size(data_ts,1);
                 Fit(1,j) = 1-length(rknnTe)/length(label_ts);
        case 'RegTree'
            str_class = num2str(data_tr(:,end));
            t = classregtree(data_tr(:,val),str_class);
            Ac1 = cell2mat(eval(t,data_ts(:,val)));  Ac1 = str2num(Ac1);
            Fit(1,j)=sum(Ac1~=data_ts(:,end))/size(data_ts,1);
        case 'NB'
            O1 = NaiveBayes.fit(data_tr(:,val),data_tr(:,end));%,'dist',F);
            Ac1 = O1.predict(data_ts(:,val));
            Fit(1,j)=sum(Ac1~=data_ts(:,end))/size(data_ts,1);
        case 'FitSVM'
            Predicted_Test_Labels_New = multisvm(data_tr(:,val),label_tr,data_ts(:,val));
            NewSVMTest = confusionmat(label_ts,Predicted_Test_Labels_New);
           Fit(1,j)= 1-sum(diag(NewSVMTest))/sum(NewSVMTest(:));
        case 'ELM'
            [~, ~, TrainingAccuracy,TestAccuracy ,TY] = elm_kernel([label_tr ,data_tr], ...
         [label_ts,data_ts], Elm_Type, Regularization_coefficient, Kernel_type, Kernel_para);
        Fit(1,j) = 1-(TestAccuracy);

        otherwise
            % put your own classifier if needed
    end
end

%load Tab.mat Pop Fit
[FFFF,x22]=sort(Fit);
Best = Pop(:,x22(1:NE));
iBest = x22;
NF1 = max([D - 5, round(D*0.65)]);

RR = zeros(1,NF);
for i=1:PSIZE
    TEMP(i,:) =zeros(1,NF);
    TEMP(i,Pop(:,i)')=1;
end
LL=[];EL=[];
LL = [LL; TEMP];                            % list of priviously tested subsets
EL = [EL;Fit'];                             % Error rates for LL subsets
PD = sum(LL((find(EL<mean(EL))),:));        % Positive feature distribution
ND = sum(LL((find(EL>=mean(EL))),:));       % Negative feature distribution
RR(find(PD+ND)==0) = 0;
RR(find(PD+ND)) = PD(find(PD+ND))./(PD(find(PD+ND))+ND(find(PD+ND)));
First = 1+ (1*RR + 1.55*(PD./max(PD)) + 0.7*(1-(PD+ND)/max(PD+ND))) ;
First = First./max(First);
Second =zeros(1,NF);
% ****************** %
% ** OPTIMIZATION ** %
% ****************** %
disp(sprintf('Iter: %d \t Err: %.4f \t Selected Subset: %s',1,Fit(iBest(1))*100,num2str(sort(round(Pop(:,iBest(1))')))))
Err(1) = (Fit(iBest(1)))*100;
for g = 2:GEN % for each generation
    expectation = fitscalingrank(Fit,NP);
    if size(expectation,2)>size(expectation,1)
        expectation=expectation';
    end
    parents = selectionstochunif(expectation,NP);
    parents =parents(randperm(length(parents)));
    OLD =Pop;
    for j = 1:NP % for each individual
        % choose three random individuals from population,
        % mutually different and different from j
        if (g<=w_varyfor) && (g > 1)
            w_now = w_now + inertdec; %Change inertia weight
        end
        r(1) = floor(rand()* NP) + 1;
        while r(1)==j
            r(1) = floor(rand()* NP) + 1;
        end
        r(2) = floor(rand()* NP) + 1;
        while (r(2)==r(1))||(r(2)==j)
            r(2) = floor(rand()* NP) + 1;
        end
        r(3) = floor(rand()* NP) + 1;
        while (r(3)==r(2))||(r(3)==r(1))||(r(3)==j)
            r(3) = floor(rand()* NP) + 1;
        end
        %-----------------------------------------------------------%
        %                    Roulette Wheel                         %
        %-----------------------------------------------------------%
        
        % create trial individual
        % in which at least one parameter is changed
        Rnd = floor(rand()*D) + 1;
        rnd = randperm(DNF);
        zq = randperm(NE);
        for i = 1:D
            if ( rand()>CR ) || ( Rnd==i )
                X(i) = Pop(rnd(i),j) + (.5./sum([Pop(rnd(i),r(2))  Best(rnd(i),zq(1))]))  * (Best(rnd(i),zq(1)) - Pop(rnd(i),r(2)) ) ;%+ w_now*(.5*rand) * (Best(i,1) - Pop(i,parents(j)));
            else
                X(i) = Pop(rnd(i),parents(j));
            end
        end
        % verify boundary constraints
        for i = 1:D
            if (X(i)<L)||(X(i)>H)
                X(i) = L + (H-L)*rand();
            end
        end
        % select the best individual
        % between trial and current ones
        % calculate fitness of trial individual
        X=X';
        S1 = unique(round(X));
        nkkk = length(S1);
        if nkkk<D
            Second = 1+ (1*RR + 1.55*(PD./max(PD)) + ((NF-DNF)/NF).*(1-(PD+ND)/max(PD+ND))) ;
            Second = Second ./max(Second);
            Tuu = (Second - First).*Second + First;
            Tuu = Tuu - 0.5.*rand(1,NF).*(1-Tuu);
            expectation = fitscalingrank(Tuu,4*D);
            if size(expectation,2)>size(expectation,1)
                expectation=expectation';
            end
            parentss = selectionstochunif(expectation,4*D);
            parentss =parentss(randperm(length(parentss)));
            ssss = unique(parentss);ssss=setdiff(ssss,S1);
            [FFFF,ts2]=sort(Tuu(ssss),'descend');
            ssss=ssss(ts2);
            X(1,1:DNF)=[S1(randperm(length(S1))) ssss(1:D-length(S1))];
        end
        
        X=X';
        val =round(X)';
        switch classif
            case 'LDA'
                %LDA classifier
                Ac1 = classify(data_ts(:,val),data_tr(:,val),label_tr,'quadratic');
                f=1-sum(Ac1~=label_ts)/size(data_ts,1);
            case 'KNN'
                %kNN classifier
                knn = fitcknn(data_tr(:,val),label_tr,'NumNeighbors',max(unique (Label)));
                predicted_label = knn.predict(data_ts(:,val));
                rknnTe = find(label_ts==predicted_label);
%                 Ac1 = knnclassify(data_ts(:,val),data_tr(:,val),label_tr,3);
%                 f=sum(Ac1~=label_ts)/size(data_ts,1);
                  f=1-length(rknnTe)/length(label_ts);
            case 'RegTree'
                str_class = num2str(data_tr(:,end));
                t = classregtree(data_tr(:,val),str_class);
                Ac1 = cell2mat(eval(t,data_ts(:,val)));  Ac1 = str2num(Ac1);
                f=sum(Ac1~=data_ts(:,end))/size(data_ts,1);
            case 'NB'
                O1 = NaiveBayes.fit(data_tr(:,val),data_tr(:,end));%,'dist',F);
                Ac1 = O1.predict(data_ts(:,val));
                f=sum(Ac1~=data_ts(:,end))/size(data_ts,1);
            case 'FitSVM'
               Predicted_Test_Labels = multisvm(data_tr(:,val),label_tr,data_ts(:,val));
               NewSVMTest1 = confusionmat(label_ts,Predicted_Test_Labels);
               f= 1-sum(diag(NewSVMTest1))/sum(NewSVMTest1(:));
            case 'ELM'
                [~, ~, TrainingAccuracy, TestAccuracy,TY] = elm_kernel([label_tr ,data_tr], ...
         [label_ts,data_ts], Elm_Type, Regularization_coefficient, Kernel_type, Kernel_para);
          f = 1- (TestAccuracy);
            otherwise
                % put your own classifier if needed
        end
        % if trial is better or equal than current
        if f <= Fit(j)
            Pop(:,j) = X; % replace current by trial
            Fit(j) = f;
            % if trial is better than the best
            if f <= Fit(iBest)
                iBest = j ; % update the best�s index
                w_now = 0.35;
            end
        end
    end
    for i=1:PSIZE
        TEMP(i,:) =zeros(1,NF);
        TEMP(i,round(Pop(:,i)'))=1;
    end
    ds =find(Fit'<EL);
    LL(ds,:) = [TEMP(ds,:)];
    EL(ds) = [Fit(ds)'];
    
    PD =  (LL((find(EL<mean(EL))),:));
    if size(PD,1)>1
        PD = sum(PD);
    else
        PD =2*rand(1,NF);
    end
    ND =  (LL((find(EL>=mean(EL))),:));
    if size(ND,1)>1
        ND = sum(ND);
    else
        ND = 2*rand(1,NF);
    end
    
    RR(find(PD+ND)==0) = 0;
    RR(find(PD+ND)) = PD(find(PD+ND))./(PD(find(PD+ND))+ND(find(PD+ND)));
    AA = (1-(PD+ND)/max(PD+ND));
    [temp,iBest] =sort(Fit);
    Best = Pop(:,iBest(1:NE));
    disp(sprintf('Iter: %d \t Err: %.4f \t Subset Selected: %s',g,Fit(iBest(1))*100,num2str(sort(round(Pop(:,iBest(1))')))))
    First = Second;
    Err(g) = (Fit(iBest(1)))*100;
    %plot (GEN,Err)
end
% ************* %
% ** RESULTS ** %
% ************* %
f = Fit(iBest(1));
Subset(p,:) = sort(round(Pop(:,iBest(1))))';
end