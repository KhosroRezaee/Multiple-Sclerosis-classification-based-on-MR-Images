function [cimg,cindex,dim]	= clipimg(img,mask)

dim	= size(img);
cindex	= find(mask~=0);
cimg	= img(cindex);
