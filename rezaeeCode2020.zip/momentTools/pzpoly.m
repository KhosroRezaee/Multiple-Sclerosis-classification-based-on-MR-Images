function	[V_nm,mag,phase]	= pzpoly(n,m,p,theta)

R_nm	= zeros(size(p));

a	= n+abs(m);
b	= n-abs(m);
total	= b;

for s=0:total
    num	= ((-1)^s)*fac(2*n+1-s)*(p.^(n-s));
    den	= fac(s)*fac(b-s)*fac(a+1-s);
    R_nm	= R_nm + num/den;
end

mag	= R_nm;
phase	= m*theta;
V_nm	= mag.*exp(i*phase);
