function	[m]	= pzpossible(n)

m	= 0:1:n;
