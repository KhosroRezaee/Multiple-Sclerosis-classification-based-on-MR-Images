function	[PZM_nm,pzmlist,cidx,V_nm]	= PZMoment(img,n,m)

%__________ REGULAR ____________________________________________________________
if nargin==1
    n	= 0;
end

d		= size(img);			% dimension
img		= double(img);

%----------	Normalize co-ordinates to [-sqrt2,sqrt2] (centroid assumed @ origin)
xstep		= 2/(sqrt(2)*(d(1)-1));
ystep		= 2/(sqrt(2)*(d(1)-1));
[x,y]		= meshgrid(-1/sqrt(2):xstep:1/sqrt(2),1/sqrt(2):-ystep:-1/sqrt(2));
%----------	compute unit disc mask
circle1		= x.^2 + y.^2;
inside		= find(circle1<=1);
mask		= zeros(d);
mask(inside)	= ones(size(inside));

%----------	mask pixels lying inside/on unit circle
[cimg,cidx]	= clipimg(img,mask);
z		= clipimg(x+i*y,mask);
p		= abs(z);
theta		= angle(z);

%----------	Compute Zernike moments
c	= 1;
for order=1:length(n)
    n1	= n(order);
    %	disp(sprintf('computing order %d',n1));
    if nargin<3
        m	= pzpossible(n1);		% repetition unspecified
    end

    for r=1:length(m)
        V_nmt		= pzpoly(n1,m(r),p,theta);
        pzprod		= cimg.*conj(V_nmt);
        PZM_nm(c)		= 2*(n1+1)*sum(sum(pzprod))/(d(1)^2*pi);
        pzmlist(c,1:2)	= [n1 m(r)];
        if nargout==4
            V_nm(:,c)	= V_nmt;
        end
        c		= c+1;
%         imshow(img)
    end
end

%__________ REGULAR ends _______________________________________________________
