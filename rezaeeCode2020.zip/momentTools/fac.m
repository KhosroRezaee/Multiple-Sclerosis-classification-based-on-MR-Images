function [factorial]	= fac(n)

%----------	find largest number
maxno		= max(max(n));

%----------	replace negative numbers and zeros by 1
zerosi		= find(n<=0);
n(zerosi)	= ones(size(zerosi));

%----------	compute factorial 
factorial	= n;
findex		= n;

for i=maxno:-1:2
	cand		= find(findex>2);
	candidates	= findex(cand);
	findex(cand)	= candidates-1;
	factorial(cand)	= factorial(cand).*findex(cand);
end
