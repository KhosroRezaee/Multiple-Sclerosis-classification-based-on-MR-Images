function [a]=pzm(x,n)
l=0;
for i=0:n
    for j=0:i
        l=l+1;
        r(1,l)=PZMoment(x,i,j);
    end
end
a=r;

